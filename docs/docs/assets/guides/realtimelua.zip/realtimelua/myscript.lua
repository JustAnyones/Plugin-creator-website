

local flameDraft = Draft.getDraft('$rtlua_flames00')

function script:draw(tileX, tileY)
  local time = City.getTime()    -- Animation timer in milliseconds

  for i = 1, 20 do
    local progress = ((time / 100 + i) / 20) % 1
    Drawing.setTile(tileX, tileY,
        31 + 10 * progress * math.sin(i * 10),
        -18 - 20 * progress * (1 + math.sin(i + 42)))
    Drawing.setColor(255, 255, 255)
    Drawing.setAlpha(1.0 - progress * progress)
    Drawing.drawImage(flameDraft:getFrame(1))
  end

  Drawing.reset()
end
